import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeloan',
  templateUrl: './homeloan.component.html',
  styleUrls: ['./homeloan.component.css']
})
export class HomeloanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  amount:number=0;
  demo(val1:number,val2:number)
  {
     
   this.amount=(val1*val2*0.04)/100;
    return `${this.amount}`;
  }

}
