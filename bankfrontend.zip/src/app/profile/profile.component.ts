import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private ser:UserService,private router:ActivatedRoute) { }
  emailid:string='';
  user2=new User;
  ngOnInit(): void {

    //console.log(this.router.snapshot.params[])

  }
  // profile(emailid:string){
  //   this.ser.profile(this.user2).subscribe(
  //     (data)=>{
        
  //       this.user2=data;
  //       console.log(data);
  //       console.log("User found");

  //     },
  //     error=>console.log("user not found")
      
  //   )

  // }

}
