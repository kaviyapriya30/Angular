import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalloanComponent } from './medicalloan.component';

describe('MedicalloanComponent', () => {
  let component: MedicalloanComponent;
  let fixture: ComponentFixture<MedicalloanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicalloanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalloanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
