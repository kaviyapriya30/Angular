import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medicalloan',
  templateUrl: './medicalloan.component.html',
  styleUrls: ['./medicalloan.component.css']
})
export class MedicalloanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  amount2:number=0;
  demo1(val1:number,val2:number)
  {
     
   this.amount2=(val1*val2*0.09)/100;
    return `${this.amount2}`;
  }


}
